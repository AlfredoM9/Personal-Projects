README

Files: hw4.1_axm180023.py
       hw4.2_axm180023.py

How to run:

hw4.1_axm180023.py [arg1] [arg2] [arg3]

This program accepts three arguments. These arguments should correspond to the paths for the three training files given from the professor. The files MUST have the word 'train' in the file name and they MUST end with a dot language name extension. For example, 'LandId.train.English' is correct. The program uses the word 'train' to distinguish between other arguments/files. Plus the language name at the end is used to identify which file is for which language.

hw4.2_axm180023.py [arg1] [arg2]

This program accepts two arguments. The first argument is the path for the test data. The second argument is the path for the correct results, the .sol extension file. The program MUST accept these arguments in that order.


Note: The hw4.1_axm180023.py will create pickle files in the current directory and hw4.2_axm180023.py will read pickle files from the current directory. This means that both programs MUST be in the same directory. 


Any Questions?
Contact: axm180023@utdallas.edu 